//
//  User+CoreDataProperties.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var city: String?
    @NSManaged public var dob: String?
    @NSManaged public var email: String?
    @NSManaged public var id: Int16
    @NSManaged public var lat: String?
    @NSManaged public var location: String?
    @NSManaged public var long: String?
    @NSManaged public var name: String?
    @NSManaged public var password: String?
    @NSManaged public var phone: String?
    @NSManaged public var postal: String?
    @NSManaged public var profilepic: NSData?
    @NSManaged public var province: String?
    @NSManaged public var userid: Int16
    @NSManaged public var userinfo: String?
    @NSManaged public var username: String?
    @NSManaged public var friends: Friends?
    @NSManaged public var myphoto: Myphotos?

}
