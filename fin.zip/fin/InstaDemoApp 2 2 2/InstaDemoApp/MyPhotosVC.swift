//
//  SecondViewController.swift
//  DemoInstagram
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-14.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

class MyPhotosVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var myPhotoObj = [Myphotos]()
    var commObj = [Comment]()
   var loguname =  String()
    var getValue = String()
    var user = [User]()
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults =  UserDefaults.standard
        
        loguname = defaults.value(forKey: "user") as! String
        
       tblView.delegate = self
        tblView.dataSource = self
        loadData()
        //self.tblView.rowHeight = UITableViewAutomaticDimension
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func loadData(){
        let request: NSFetchRequest<User> = User.fetchRequest()
        let query=NSPredicate(format: "username==%@",loguname)
        request.predicate=query
        do {
            user=try myContext.fetch(request)
        }catch{
            print("Exception is : \(error)")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
    
        let requestforpic : NSFetchRequest<Myphotos> = Myphotos.fetchRequest()
        let query=NSPredicate(format: "uname==%@ ",loguname)
        requestforpic.predicate=query
        
        let requestforcomm : NSFetchRequest<Comment> = Comment.fetchRequest()
        do{
            myPhotoObj =  try myContext.fetch(requestforpic)
            commObj = try myContext.fetch(requestforcomm)
        }
            
        catch{
            print("Error : \(error)")
        }
        self.tblView.reloadData()
    }
    
    //MARK: - Tableview Methods
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        
        return myPhotoObj.count
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        
        
            let cell:PostCell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as! PostCell
        
        let pic = myPhotoObj[indexPath.row]
        
      /*  let com = commObj[indexPath.row]
        cell.lblPostCaption.text = com.commenttext*/
        cell.imgPost.image = UIImage(data: pic.photo! as Data)
        return cell
            
            
        
        
       
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        getValue = myPhotoObj[indexPath.row].tag!
        self.performSegue(withIdentifier: "showc", sender: self)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
         let cell:PostHeaderCell = tableView.dequeueReusableCell(withIdentifier: "PostHeaderCell") as! PostHeaderCell
        cell.lblUserName.text = loguname
        if(user[0].profilepic != nil){
            cell.imgUserProfilepic.image =  UIImage(data: user[0].profilepic! as Data)
        }else{
            cell.imgUserProfilepic.image = UIImage(named: "3")
        }

        return cell
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)//Segue to send data to CheckResultView view controller.
    {
        if (segue.identifier == "showc")
        {
            let signup =  segue.destination as! AddCommentVC
            signup.picname = getValue
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 57
    }
    
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 624
    }
    
   

}

