//
//  FeedCell.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-04-03.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class FeedCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    
    
}
