
import UIKit
import CoreData
import LocalAuthentication

class LoginVC: UIViewController {
    
    @IBOutlet var tfUsername: UITextField!
    
    @IBOutlet var tfPassword: UITextField!
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var dbresult=[User]()
    var rem=[Remeber]()
    var getUname=String()
    
    var c=1
    func checkOnline(){
        let request: NSFetchRequest<Remeber> = Remeber.fetchRequest()
        
        do {
            rem=try myContext.fetch(request)
            if(rem.count>0){
                getUname=rem[0].uname!
                self.performSegue(withIdentifier: "tabBar", sender: self)
            }
        }catch{
            print("\(error)")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tfUsername.text=""
        tfPassword.text=""
        
        self.title = "Instagram"
        
        checkOnline()
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        let path=FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(path)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
    }
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func btnSwitchTapped(_ sender: Any) {
        if(c==1){
            c=2
        }else if(c==2){
            c=1
        }
    }
   
    @IBAction func btnSignupTapped(_ sender: Any) {
        self.performSegue(withIdentifier: "SignUpVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)//Segue to send data to CheckResultView view controller.
    {
        if (segue.identifier == "SignUpVC")
        {
            let signup =  segue.destination as! SignupVC
        }else if(segue.identifier == "tabBar"){
            let userview =  segue.destination as! UserPage
            userview.loguname = getUname
        }
    }
    func saveData(){
        do{
            try myContext.save()
        }catch{
            print("Exception is : \(error)")
        }
    }
    @IBAction func btnLoginTapped(_ sender: Any) {
        let uname=tfUsername.text!
        let password=tfPassword.text!
        getUname=tfUsername.text!
        if(uname == "" || password == ""){
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }else{
           
            let request: NSFetchRequest<User> = User.fetchRequest()
            let query=NSPredicate(format: "username==%@ and password==%@",uname,password)
            request.predicate=query
            do {
               
                dbresult=try myContext.fetch(request)
                if(dbresult.count > 0){
                     if(c==2){
                         let rem=Remeber(context: self.myContext)
                         rem.uname = tfUsername.text!
                         saveData()
                     }
                    self.performSegue(withIdentifier: "tabBar", sender: self)
                    
                }else{
                    let alert = UIAlertController(title: "Error Message", message: "Username or Password must be Wrong", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }catch{
                print("Exception is : \(error)")
            }
        }
      
    }
}


