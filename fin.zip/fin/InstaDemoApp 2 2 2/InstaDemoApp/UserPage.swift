//
//  UserPage.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-03-31.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class UserPage: UITabBarController {
    var loguname=String()
    override func viewDidLoad() {
        super.viewDidLoad()
        print(loguname)
        navigationItem.hidesBackButton = true
        let defaults =  UserDefaults.standard
        
        defaults.set(loguname, forKey: "user")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
