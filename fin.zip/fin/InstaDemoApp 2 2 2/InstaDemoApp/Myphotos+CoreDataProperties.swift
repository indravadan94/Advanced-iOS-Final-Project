//
//  Myphotos+CoreDataProperties.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension Myphotos {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Myphotos> {
        return NSFetchRequest<Myphotos>(entityName: "Myphotos")
    }

    @NSManaged public var likes: Int16
    @NSManaged public var photo: NSData?
    @NSManaged public var tag: String?
    @NSManaged public var uname: String?
    @NSManaged public var comment: Comment?
    @NSManaged public var user: NSSet?

}

// MARK: Generated accessors for user
extension Myphotos {

    @objc(addUserObject:)
    @NSManaged public func addToUser(_ value: User)

    @objc(removeUserObject:)
    @NSManaged public func removeFromUser(_ value: User)

    @objc(addUser:)
    @NSManaged public func addToUser(_ values: NSSet)

    @objc(removeUser:)
    @NSManaged public func removeFromUser(_ values: NSSet)

}
