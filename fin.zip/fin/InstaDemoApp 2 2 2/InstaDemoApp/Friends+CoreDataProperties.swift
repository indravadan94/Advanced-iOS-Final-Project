//
//  Friends+CoreDataProperties.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension Friends {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Friends> {
        return NSFetchRequest<Friends>(entityName: "Friends")
    }

    @NSManaged public var frdId: Int16
    @NSManaged public var frdUserName: String?
    @NSManaged public var lat: Float
    @NSManaged public var location: String?
    @NSManaged public var long: Float
    @NSManaged public var comment: Comment?
    @NSManaged public var userid: User?

}
