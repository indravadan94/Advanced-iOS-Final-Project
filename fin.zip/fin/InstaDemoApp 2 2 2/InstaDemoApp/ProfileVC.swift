import UIKit
import CoreData

class ProfileVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    var ch=1
    var loguname =  String()
    var img : UIImage!
    var imagePicker: UIImagePickerController!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var bgimgView: UIImageView!
    
    
    @IBOutlet weak var tfuserName: UITextField!
    
    @IBOutlet weak var info: UITextField!
    
    @IBOutlet weak var tfUserNumber: UITextField!
    
    
    
    //MARK: - CoreData Stuff
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var user = [User]()
    
    var rem = [Remeber]()
    
    
    func saveData()
    {
        do{
            try myContext.save()
        }
        catch{
            print("Error : \(error)")
        }
    }
    
    func loadData(){
        
        print("My NAme is : \(loguname)")
        let request: NSFetchRequest<User> = User.fetchRequest()
        let query=NSPredicate(format: "username==%@",loguname)
        request.predicate=query
        do {
            user=try myContext.fetch(request)
            if(user.count > 0){
                if(ch==1){
                    tfUserNumber.text=user[0].phone!
                    info.text=user[0].userinfo!
                    tfuserName.text=user[0].name!
                    if(user[0].profilepic != nil){
                        imgView.image = UIImage(data: user[0].profilepic! as Data)
                    }else{
                        imgView.image = UIImage(named: "3")
                    }
                }else if(ch==2){
                    user[0].phone=tfUserNumber.text!
                    user[0].userinfo=info.text!
                    user[0].name=tfuserName.text!
                    
                    saveData()
                }
                
            }
        }catch{
            print("Exception is : \(error)")
        }
    }
    
   
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults =  UserDefaults.standard
        
        loguname = defaults.value(forKey: "user") as! String
        loadData()
        
        
        
     //Imageview Properties
        let myColor : UIColor = UIColor.white
        self.imgView.layer.borderWidth = 3.0;
        self.imgView.layer.borderColor = myColor.cgColor
        self.imgView.layer.cornerRadius = 10.0;
        self.imgView.layer.masksToBounds = true
       
      //Tap Gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imgView.isUserInteractionEnabled = true
        imgView.addGestureRecognizer(tapGestureRecognizer)
        
        
        //Blur ImageBackground
        let darkBlur = UIBlurEffect(style: UIBlurEffectStyle.light)
        let blurView = UIVisualEffectView(effect: darkBlur)
        blurView.frame = bgimgView.bounds
        bgimgView.addSubview(blurView)
    }
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            img = pickedImage
            imgView.image = pickedImage
            
            let request: NSFetchRequest<User> = User.fetchRequest()
            let query=NSPredicate(format: "username==%@",loguname)
            request.predicate=query
            do {
                
                if(user.count > 0){
                    
                    user[0].profilepic =  UIImageJPEGRepresentation(pickedImage, 1) as NSData?;
                    
                    saveData()
                }
            }catch{
                print("Exception is : \(error)")
            }
            
        }
    }
    
    
    
    //MARK: - Button Update Action
    @IBAction func btnUpdateTapped(_ sender: UIButton) {
        if(tfUserNumber.text! == "" || tfuserName.text! == "" || info.text! == ""){
            print("All Fields are required")
        }else{
            ch=2
            loadData()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let requestforpic : NSFetchRequest<User> = User.fetchRequest()
        
        do{
            user =  try myContext.fetch(requestforpic)
            
        }
            
        catch{
            print("Error : \(error)")
        }
        
    }
    //MARK: - Tap Gesture on ImageView
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        _ = tapGestureRecognizer.view as! UIImageView
        
        // Your action
        
        let alert = UIAlertController(title: "Alert", message: "Choose Profile Pic", preferredStyle: .actionSheet)
        
        let action1 = UIAlertAction(title: "Take Picture", style: .default, handler: {action in
            
            self.imagePicker =  UIImagePickerController()
            self.imagePicker.delegate = self as UIImagePickerControllerDelegate & UINavigationControllerDelegate
            self.imagePicker.sourceType = .camera
            self.present(self.imagePicker, animated: true, completion: nil)
            })
        let action2 = UIAlertAction(title: "Choose from Gallery", style: .default, handler: {action in
            
            self.imagePicker =  UIImagePickerController()
            self.imagePicker.delegate = self as UIImagePickerControllerDelegate & UINavigationControllerDelegate
            self.imagePicker.allowsEditing = true
            self.imagePicker.sourceType = .photoLibrary
            
            self.present(self.imagePicker, animated: true, completion: nil)
        })
        
        let action3 = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        
        
        
        alert.addAction(action1)
        alert.addAction(action2)
        alert.addAction(action3)
    
   self.present(alert, animated: true, completion: nil)
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func deleteRember(){
        let request: NSFetchRequest<Remeber> = Remeber.fetchRequest()
        do {
            
            rem=try myContext.fetch(request)
            if(rem.count>0){
                self.myContext.delete(self.rem[0])
                self.saveData()
            }
        }catch{
            print("\(error)")
        }
    }
    @IBAction func btnLogoutTapped(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
        self.deleteRember()
    }
}

