//
//  TableViewCell.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-23.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
