//
//  PostHeaderCell.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-23.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit

class PostHeaderCell: UITableViewCell {

    @IBOutlet weak var imgUserProfilepic: UIImageView!
    
    @IBOutlet weak var lblUserName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        imgUserProfilepic.layer.cornerRadius = imgUserProfilepic.bounds.width/2.0
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

    
}
