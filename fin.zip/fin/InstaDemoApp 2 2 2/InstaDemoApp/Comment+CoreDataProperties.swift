//
//  Comment+CoreDataProperties.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData


extension Comment {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Comment> {
        return NSFetchRequest<Comment>(entityName: "Comment")
    }

    @NSManaged public var commenttext: String?
    @NSManaged public var tag: String?
    @NSManaged public var date: NSDate?
    @NSManaged public var time: NSDate?
    @NSManaged public var frnUserId: Friends?
    @NSManaged public var photoid: NSSet?

}

// MARK: Generated accessors for photoid
extension Comment {

    @objc(addPhotoidObject:)
    @NSManaged public func addToPhotoid(_ value: Myphotos)

    @objc(removePhotoidObject:)
    @NSManaged public func removeFromPhotoid(_ value: Myphotos)

    @objc(addPhotoid:)
    @NSManaged public func addToPhotoid(_ values: NSSet)

    @objc(removePhotoid:)
    @NSManaged public func removeFromPhotoid(_ values: NSSet)

}
