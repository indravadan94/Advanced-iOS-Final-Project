//
//  FriendsVC.swift
//  DemoInstagram
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-22.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

 var user = [User]()
 var loguname =  String()


class FriendsVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnNearBy: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults =  UserDefaults.standard
        loguname = defaults.value(forKey: "user") as! String
        // Do any additional setup after loading the view.
        load()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func load(){
        let request : NSFetchRequest<User> = User.fetchRequest()
        let query=NSPredicate(format: "username != %@ ",loguname)
        request.predicate=query
        
        do{
            user = try myContext.fetch(request)
        }
        catch{
            print("Error is :  \(error)")
        }
    }
    //MARK: - Button NearBy Tapped Action
    
    @IBAction func btnNearBy(_ sender: Any) {
        
        
    }
    
    
    //MARK: - Tableview Methods
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  user.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let name = User(context: myContext)
        
        let n = user[indexPath.row]
        
        
        
        cell.textLabel?.text = n.username
        cell.detailTextLabel?.text = n.city
        return cell
    }
    
    @IBAction func btnNearByTapped(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dest = segue.destination as! MapVC
        let index = tblView.indexPathForSelectedRow
        if (index != nil) {
          //  dest.username = user[index!.row].username!
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "nextVC", sender: self)
    }
}
