//
//  FeedVC.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-04-03.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

class FeedVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var CView: UICollectionView!
    
    var loguname=String()
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var myPhotoObj = [Myphotos]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let itemSize = UIScreen.main.bounds.width/3 - 3
        
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: itemSize, height: itemSize)
        layout.sectionInset = UIEdgeInsetsMake(20, 0, 10, 0)
        layout.minimumInteritemSpacing = 3
        layout.minimumLineSpacing = 3
        
        CView.collectionViewLayout = layout
        print(loguname)
        CView.delegate = self
        CView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let requestforpic : NSFetchRequest<Myphotos> = Myphotos.fetchRequest()
        
        do{
            myPhotoObj =  try myContext.fetch(requestforpic)
        }
            
        catch{
            print("Error : \(error)")
        }
        self.CView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myPhotoObj.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! FeedCell
        let pic = myPhotoObj[indexPath.row]
        cell.imgView.image = UIImage(data: pic.photo! as Data)
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
