//
//  PostVC.swift
//  DemoInstagram
//
//  Created by INDRAVADAN SHRIMALI on 2018-03-22.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData

class PostVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    var loguname =  String()
    
    @IBOutlet weak var imgView: UIImageView!
    var img : UIImage!
    var imagePicker: UIImagePickerController!
    @IBOutlet weak var mySegment: UISegmentedControl!
    
    
    //MARK: - Coredat Stuff
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var myPhotoObj = [Myphotos]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults =  UserDefaults.standard
        
        loguname = defaults.value(forKey: "user") as! String
        
        loadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func saveData()
    {
        do{
            try myContext.save()
        }
       catch{
            print("Error : \(error)")
        }
    }
    
    func loadData(){
        let request : NSFetchRequest<Myphotos> = Myphotos.fetchRequest()
        //let query = NSPredicate(format: "category.name MATCHES %@", (genre!.name!))
        //request.predicate = query
        do{
            myPhotoObj =  try myContext.fetch(request)
        }
            
        catch{
            print("Error : \(error)")
        }
    }
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "Your altered image has been saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }
    
    //MARK: - Done image capture here
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
       
        imgView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        img = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        let myphoto = Myphotos(context: self.myContext)
        
        myphoto.photo = UIImageJPEGRepresentation(img, 1) as NSData?;
        myphoto.uname = loguname
        let date = Date()
        let calendar = Calendar.current
        
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let seconds = calendar.component(.second, from: date)
        let tag = "\(loguname)\(hour)\(minutes)\(seconds)"
        print("\(tag)")
        myphoto.tag = tag
        
        
        self.myPhotoObj.append(myphoto)
        
        
        self.saveData()
        
         UIImageWriteToSavedPhotosAlbum(imgView.image!, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }

    
    
    
    @IBAction func mySegmentTapped(_ sender: UISegmentedControl)
    {
        if mySegment.selectedSegmentIndex == 0
        {
            
            if (UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType .camera)){
                
                
                imagePicker =  UIImagePickerController()
                imagePicker.delegate = self as UIImagePickerControllerDelegate & UINavigationControllerDelegate
                imagePicker.sourceType = .camera
                present(imagePicker, animated: true, completion: nil)
            }
            
            else
            {
                let alert = UIAlertController(title: "Alert", message: "Source type not available!!", preferredStyle: .alert)
                
                let btnOk = UIAlertAction(title: "OK", style: .default, handler: nil)
                
                alert.addAction(btnOk)
                
                self.present(alert, animated: true, completion: nil)
            }
        }
        
        else
        
        {
            imagePicker =  UIImagePickerController()
            imagePicker.delegate = self as UIImagePickerControllerDelegate & UINavigationControllerDelegate
            imagePicker.allowsEditing = true
            imagePicker.sourceType = .photoLibrary
            
            present(imagePicker, animated: true, completion: nil)
        }
            
        }
    }
