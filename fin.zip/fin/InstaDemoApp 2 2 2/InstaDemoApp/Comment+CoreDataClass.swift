//
//  Comment+CoreDataClass.swift
//  InstaDemoApp
//
//  Created by Tasbir Singh on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Comment)
public class Comment: NSManagedObject {

}
