//
//  SignupVC.swift
//  instaAppPuneet
//
//  Created by Vishal Verma on 2018-03-24.
//  Copyright © 2018 Vishal Verma. All rights reserved.
//

import UIKit

import CoreData

class SignupVC: UIViewController {
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var dbresult=[User]()
    var dbresult1=[User]()
    
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var dob: UITextField!
    @IBOutlet weak var email: UITextField!
     @IBOutlet weak var addr: UITextView!
   
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var pwd: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var postal: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var cpwd: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        createDatePicker()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        let path=FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(path)
        // Do any additional setup after loading the view.
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    @IBAction func register(_ sender: UIButton) {
           let providedEmailAddress = email.text
         let isEmailAddressValid = isValidEmailAddress(emailAddressString: providedEmailAddress!)
         
         if(phone.text!=="" || email.text!=="" || name.text!=="" || dob.text!=="" || pwd.text!=="" || cpwd.text!=="" || username.text!=="" || postal.text!=="" || state.text!=="" || city.text!=="" || addr.text!=="" ){
         let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
         alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
         self.present(alert, animated: true, completion: nil)
         }else if(pwd.text! != cpwd.text!){
         let alert = UIAlertController(title: "Error Message", message: "Password Not Matched", preferredStyle: UIAlertControllerStyle.alert)
         alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
         self.present(alert, animated: true, completion: nil)
         }else if (!isEmailAddressValid){
         let alert = UIAlertController(title: "Error Message", message: "Email Id is not Valid", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
         }else if(phone.text!.count != 10){
            let alert = UIAlertController(title: "Error Message", message: "Phone number is not Valid", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
         }else{
            let request: NSFetchRequest<User> = User.fetchRequest()
            let requestt: NSFetchRequest<User> = User.fetchRequest()
            
            let query=NSPredicate(format: "username==%@ ",username.text!)
            request.predicate=query
            
            let queryy=NSPredicate(format: "email==%@",email.text!)
            requestt.predicate=queryy
            
            
            do {
                dbresult=try myContext.fetch(request)
                dbresult1=try myContext.fetch(requestt)
                
                if(dbresult.count != 0){
                    let alert = UIAlertController(title: "Error Message", message: "Username already Exist", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    username.text=""
                }else if(dbresult1.count != 0){
                    let alert = UIAlertController(title: "Error Message", message: "Email already Exist", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    email.text=""
                }else{
                    let user=User(context: self.myContext)
                    user.username = username.text!
                    user.id=1
                    //user.profilepic = 
                    user.userinfo=""
                    user.province=state.text!
                    user.postal=postal.text!
                    user.phone=phone.text!
                    user.password=pwd.text!
                    user.name = name.text!
                  
                    user.location = addr.text!
                   
                    user.email=email.text!
                    user.dob=dob.text!
                    user.city=city.text!
                    saveData()
                    
                }
            }catch{
                print("Exception is : \(error)")
            }
          }
        
        
    }
    func saveData(){
        do{
            try myContext.save()
            let alert = UIAlertController(title: "Success", message: "Data Registered", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            phone.text=""
            email.text=""
            name.text=""
            dob.text=""
            
            pwd.text=""
            cpwd.text=""
            username.text=""
            postal.text=""
            state.text=""
            city.text=""
            
            addr.text=""
           
            
        }catch{
            print("Exception is : \(error)")
        }
    }
    @IBAction func reset(_ sender: UIButton) {
        
         phone.text=""
         email.text=""
         name.text=""
         dob.text=""
         
         pwd.text=""
         cpwd.text=""
         username.text=""
         postal.text=""
         state.text=""
         city.text=""
         
         addr.text=""
        
        
    }
    
    
        let picker=UIDatePicker()
    
     @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
     self.view.endEditing(true);
     }
     
     func createDatePicker(){
     let toolbar=UIToolbar()
     toolbar.sizeToFit()
     let done=UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
     toolbar.setItems([done], animated: false)
     dob.inputAccessoryView=toolbar
     dob.inputView=picker
     picker.datePickerMode = .date
     
     }
     @objc func donePressed(){
     let formatter=DateFormatter()
     formatter.dateStyle = .medium
     formatter.timeStyle = .none
     let dateString = formatter.string(from: picker.date)
     dob.text="\(dateString)"
     self.view.endEditing(true)
     }
     
    
}
