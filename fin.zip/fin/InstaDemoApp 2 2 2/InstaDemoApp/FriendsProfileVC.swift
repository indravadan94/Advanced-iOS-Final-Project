//
//  FriendsProfileVC.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-04-02.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData
class FriendsProfileVC: UIViewController {
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var user = [User]()
    @IBOutlet weak var imgView: UIImageView!
    var username=String()
    
    @IBOutlet weak var email: UILabel!
    
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
    }
    func loadData(){
        let request : NSFetchRequest<User> = User.fetchRequest()
        let query=NSPredicate(format: "username == %@ ",username)
        request.predicate=query
        
        do{
            user = try myContext.fetch(request)
            if(user.count>0){
                if(user[0].profilepic != nil){
                    imgView.image = UIImage(data: user[0].profilepic! as Data)
                }else{
                    imgView.image = UIImage(named: "3")
                }
                email.text! = "Email : \(user[0].email!)"
                name.text! = "Name : \(user[0].name!)"
                phone.text! = "Phone : \(user[0].phone!)"
                
                
            }
        }
        catch{
            print("Error is :  \(error)")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
