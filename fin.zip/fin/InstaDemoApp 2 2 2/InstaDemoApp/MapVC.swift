//
//  MapViewController.swift
//  MyInstagramApp
//
//  Created by Indravadan Shrimali on 2018-03-27.
//  Copyright © 2018 chamandeep kaur. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapVC: UIViewController, CLLocationManagerDelegate,MKMapViewDelegate {
    @IBOutlet weak var map: MKMapView!
    
    // -- MARK: Variables
    var manager : CLLocationManager!
    
    let LocationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        
        LocationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled(){
            LocationManager.delegate = self
            LocationManager.desiredAccuracy = kCLLocationAccuracyBest
            LocationManager.startUpdatingLocation()
        }
        let location = CLLocationCoordinate2DMake(43.770562, -79.333015)
        let location1 = CLLocationCoordinate2DMake(42.776698, -78.340375)
        let location2 = CLLocationCoordinate2DMake(41.776760, -77.337414)
        let location3 = CLLocationCoordinate2DMake(40.776760, -76.340997)
        let location4 = CLLocationCoordinate2DMake(45.771403, -70.327184)
        let marker = MKPointAnnotation()
        
        marker.coordinate = location
        marker.title = "Toronto"
        map.addAnnotation(marker)
        
        let marker1 = MKPointAnnotation()
        marker1.coordinate = location1
        marker1.title = "Mississauga"
        map.addAnnotation(marker1)
        
        let marker2 = MKPointAnnotation()
        marker2.coordinate = location2
        marker2.title = "Brampton"
        map.addAnnotation(marker2)
        
        let marker3 = MKPointAnnotation()
        marker3.coordinate = location3
        marker3.title = "Berry"
        map.addAnnotation(marker3)
        
        let marker4 = MKPointAnnotation()
        marker4.coordinate = location4
        marker4.title = "Toronto"
        map.addAnnotation(marker4)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last! as CLLocation
        let newPin = MKPointAnnotation()
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion( center: center,  span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        //set region on the map
        map.setRegion(region, animated: true)
        
        newPin.coordinate = location.coordinate
        newPin.title = "Me"
        map.addAnnotation(newPin)
        
        
        
    }
}
