//
//  AddCommentVC.swift
//  InstaDemoApp
//
//  Created by INDRAVADAN SHRIMALI on 2018-04-03.
//  Copyright © 2018 INDRAVADAN SHRIMALI. All rights reserved.
//

import UIKit
import CoreData
class AddCommentVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var tblView: UITableView!
    
    
    
    @IBOutlet weak var textc: UITextField!
    
    @IBOutlet weak var btnComment: UIButton!
    
    
    
    
    
    
    var picname = String()
    var cm=[Comment]()
    var photo=[Myphotos]()
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        loadData()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
    }
    func loadData() {
        let request: NSFetchRequest<Myphotos> = Myphotos.fetchRequest()
        
        let request1: NSFetchRequest<Comment> = Comment.fetchRequest()
        

        
        let query=NSPredicate(format: "tag==%@",picname)
        request.predicate=query
        request1.predicate=query
        do {
            photo=try myContext.fetch(request)
            cm=try myContext.fetch(request1)
            imgView.image = UIImage(data: photo[0].photo! as Data)
        }catch{
            print("Exception is : \(error)")
        }
    }
    override func viewDidAppear(_ animated: Bool) {
//        self.tblView.clearsContextBeforeDrawing
        loadData()
        self.tblView.reloadData()
    }
    @IBAction func btnCommentTapped(_ sender: Any) {
        if(textc.text! == ""){
            print("Add Comment")
        }else{
            do{
                let cmmt=Comment(context: self.myContext)
                cmmt.tag = picname
                cmmt.commenttext = textc.text!
                saveData()
                
            }catch{
                print("/(error)")
            }
            loadData()
            self.tblView.reloadData()
            textc.text = ""
            
        }
    }
    func saveData(){
        do{
            try myContext.save()
            let alert = UIAlertController(title: "Success", message: "Comment Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }catch{
            print("Exception is : \(error)")
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return cm.count;
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = cm[indexPath.row].commenttext
        
        return cell
    }
    


}
