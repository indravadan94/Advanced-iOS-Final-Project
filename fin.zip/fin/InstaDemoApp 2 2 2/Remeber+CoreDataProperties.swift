
import Foundation
import CoreData


extension Remeber {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Remeber> {
        return NSFetchRequest<Remeber>(entityName: "Remeber")
    }

    @NSManaged public var uname: String?

}
